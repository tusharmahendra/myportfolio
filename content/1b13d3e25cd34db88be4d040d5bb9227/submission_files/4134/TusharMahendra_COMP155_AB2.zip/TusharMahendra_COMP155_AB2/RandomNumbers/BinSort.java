
public class BinSort {
	
	/**
	 * @author tusharmahendra
	 * 
	 * <h1> Generating and Printing Bins </h1>
	 * 
	 * @param BinSort
	 * <p> BinSort is a constructor in a class which is used to assign objects (sorter) to the class (BinSort). This constructor is receiving values of three variables from the Main file RandomPlay. </p>
	 *  
	 * @param generateBins
	 * <p> In this method, there's a loop until the samples that stores a random value generated in Random.java file into rNum. rNum is divided by BIN_WIDTH to get the index value for binCount. Index value is incremented for the time loop runs. <p/>
	 * 
	 * @param printBins
	 * <p> To print the bins, loop starts from the value of binCount array's length. Within this loop which prints "*" till the last element of binCount. Further it runs the outer loop again and prints "*" in next line. Furthermore, binMin and binMax are derived by the given formula and printed out. </p>
	 */
	
	final int MAX;
	final int N_BINS;
	final int N_SAMPLES;
	final float BIN_WIDTH ;
	int [] binCount;
	int bin, temp;
	float binMin, binMax;
	
	BinSort (int max, int nBins, int nSamples){
	MAX = max;
	N_BINS = nBins;
	N_SAMPLES = nSamples;	
	BIN_WIDTH = (float) (MAX / N_BINS); //
	binCount = new int [N_BINS];	
	}
	 
	void generateBins() {	
		for ( int i = 0; i <= (N_SAMPLES-1); i++) {
			int rNum = Random.rand(i, MAX);
			temp = (int) (rNum/BIN_WIDTH);
			bin = (int) Math.floor(temp);
			binCount [bin] ++; 
		}		
	}
		
	void printBins() {
		
		for( int i = binCount.length-1; i >= 0 ; i--) {
			for( int j = 0; j < binCount[i]; j++) {
				System.out.print("*");
				
			}
			
			binMin = i * BIN_WIDTH;
			binMax = binMin + BIN_WIDTH;
			System.out.println("[" + binMin + ", " + binMax + ")");
			System.out.print("\n");
		}			
	}
	
}
		
	