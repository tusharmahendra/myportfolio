
public class RandomPlay {
	/**
	 *@author tusharmahendra
	 *
	 *<h1> Calling The Methods </h1>
	 * 
	 * @param BinSort - It is used to call the constructor and initialise the values provided into it.
	 * 
	 * @param generateBins() - It's a calling generateBins through object (sorter) for BinSort class.
	 * 
	 * @param printBins() - It's a calling printBins through object (sorter) for BinSort class.
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		
		/*
		 * University of the Fraser Valley
		 * COMP 155 (AB2)
		 * Name:  Tushar Mahendra
		 * Student Number:  300156940
		 * Assignment 1:  Generating and printing bins
		 */
		 
		System.out.println("12 random integers in [0, 10) sorted into 2 bins:");
		BinSort sorter = new BinSort(10, 2, 12);
		sorter.generateBins();
		sorter.printBins();
	}
}
